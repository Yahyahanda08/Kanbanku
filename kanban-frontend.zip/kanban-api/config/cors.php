<?php

return [

    'paths' => [
        'api/*',
        'broadcasting/auth', // 🔥 penting untuk realtime
        'sanctum/csrf-cookie',
    ],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        'http://localhost:5173',
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => true, // 🔥 WAJIB untuk auth (Bearer / cookies)

];