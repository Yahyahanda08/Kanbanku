<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Column;
use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function store(Request $request, Column $column)
    {
        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'priority'    => 'in:low,medium,high',
            'due_date'    => 'nullable|date',
            'assigned_to' => 'nullable|exists:users,id',
        ]);

        // Set default priority if not provided
        $data['priority'] = $data['priority'] ?? 'medium';

        $position = $column->tasks()->max('position') + 1;

        $task = $column->tasks()->create([
            'title'       => $data['title'],
            'description' => $data['description'] ?? null,
            'priority'    => $data['priority'],
            'due_date'    => $data['due_date'] ?? null,
            'assigned_to' => $data['assigned_to'] ?? null,
            'position'    => $position,
        ]);

        // Return with assignee relation loaded
        return response()->json($task->load('assignee'), 201);
    }

    public function show(Task $task)
    {
        return response()->json($task->load(['assignee', 'comments.user']));
    }

    public function update(Request $request, Task $task)
    {
        $validated = $request->validate([
            'title'       => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'priority'    => 'sometimes|in:low,medium,high',
            'due_date'    => 'nullable|date',
            'assigned_to' => 'nullable|exists:users,id',
        ]);

        $task->update($validated);

        return response()->json($task->load('assignee'));
    }

    public function move(Request $request, Task $task)
    {
        $request->validate([
            'column_id' => 'required|exists:columns,id',
            'position'  => 'required|integer|min:0',
        ]);

        // Validate target column is in same board
        $targetColumn = Column::findOrFail($request->column_id);
        if ($targetColumn->board_id !== $task->column->board_id) {
            return response()->json(['message' => 'Kolom tidak dalam board yang sama'], 403);
        }

        // Shift positions in old column
        Task::where('column_id', $task->column_id)
            ->where('position', '>', $task->position)
            ->decrement('position');

        // Shift positions in new column
        Task::where('column_id', $request->column_id)
            ->where('position', '>=', $request->position)
            ->increment('position');

        $task->update([
            'column_id' => $request->column_id,
            'position'  => $request->position,
        ]);

        return response()->json($task->fresh()->load('assignee'));
    }

    public function destroy(Task $task)
    {
        $task->delete();
        return response()->json(null, 204);
    }
}