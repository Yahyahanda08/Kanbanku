<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Board;
use App\Models\Column;
use Illuminate\Http\Request;

class ColumnController extends Controller
{
    public function store(Request $request, Board $board)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $position = $board->columns()->max('position') + 1;
        $column   = $board->columns()->create([
            'name'     => $data['name'],
            'position' => $position,
        ]);

        return response()->json($column, 201);
    }

    public function update(Request $request, Column $column)
    {
        $column->update($request->validate([
            'name' => 'required|string|max:255',
        ]));

        return response()->json($column);
    }

    public function destroy(Column $column)
    {
        $column->delete();
        return response()->json(null, 204);
    }
}