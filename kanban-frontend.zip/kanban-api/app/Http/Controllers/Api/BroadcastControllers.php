<?php
// Tambahkan broadcast() di setiap controller yang mengubah board
// Contoh: ColumnController.php & TaskController.php

// ─────────────────────────────────────────────────────────────
// ColumnController
// ─────────────────────────────────────────────────────────────

namespace App\Http\Controllers;

use App\Events\BoardUpdated;
use App\Models\Column;
use App\Models\Board;
use Illuminate\Http\Request;

class ColumnController extends Controller
{
    // Reorder kolom
    public function reorder(Request $request, $boardId)
    {
        $request->validate(['columns' => 'required|array']);

        foreach ($request->columns as $index => $colId) {
            Column::where('id', $colId)
                  ->where('board_id', $boardId)
                  ->update(['position' => $index]);
        }

        // Broadcast ke semua member board
        broadcast(new BoardUpdated(
            boardId: (int) $boardId,
            type: 'column_reordered',
            payload: ['column_ids' => $request->columns],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json(['ok' => true]);
    }

    // Store kolom baru
    public function store(Request $request, $boardId)
    {
        $request->validate(['name' => 'required|string|max:255']);

        $position = Column::where('board_id', $boardId)->max('position') + 1;
        $column = Column::create([
            'board_id' => $boardId,
            'name'     => $request->name,
            'position' => $position,
        ]);

        broadcast(new BoardUpdated(
            boardId: (int) $boardId,
            type: 'column_created',
            payload: ['column' => $column->load('tasks')],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json($column, 201);
    }

    // Update / rename kolom
    public function update(Request $request, $columnId)
    {
        $column = Column::findOrFail($columnId);
        $column->update($request->only('name'));

        broadcast(new BoardUpdated(
            boardId: $column->board_id,
            type: 'column_renamed',
            payload: ['column_id' => $columnId, 'name' => $column->name],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json($column);
    }

    // Hapus kolom
    public function destroy($columnId)
    {
        $column = Column::findOrFail($columnId);
        $boardId = $column->board_id;
        $column->delete();

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'column_deleted',
            payload: ['column_id' => (int) $columnId],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json(['ok' => true]);
    }
}

// ─────────────────────────────────────────────────────────────
// TaskController
// ─────────────────────────────────────────────────────────────

class TaskController extends Controller
{
    // Pindahkan card ke kolom lain atau reorder
    public function move(Request $request, $taskId)
    {
        $request->validate([
            'column_id' => 'required|integer',
            'position'  => 'required|integer',
        ]);

        $task = \App\Models\Task::findOrFail($taskId);
        $boardId = \App\Models\Column::findOrFail($request->column_id)->board_id;

        $task->update([
            'column_id' => $request->column_id,
            'position'  => $request->position,
        ]);

        // Reorder task lain di kolom tujuan
        \App\Models\Task::where('column_id', $request->column_id)
            ->where('id', '!=', $taskId)
            ->where('position', '>=', $request->position)
            ->increment('position');

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'card_moved',
            payload: [
                'task_id'   => (int) $taskId,
                'column_id' => $request->column_id,
                'position'  => $request->position,
            ],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json(['ok' => true]);
    }

    // Update card (title, desc, priority, dll)
    public function update(Request $request, $taskId)
    {
        $task = \App\Models\Task::findOrFail($taskId);
        $task->update($request->only([
            'title', 'description', 'priority',
            'due_date', 'is_completed', 'bg_color',
        ]));

        $boardId = $task->column->board_id;

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'card_updated',
            payload: ['task' => $task->fresh()],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json($task);
    }

    // Hapus card
    public function destroy($taskId)
    {
        $task = \App\Models\Task::findOrFail($taskId);
        $boardId = $task->column->board_id;
        $task->delete();

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'card_deleted',
            payload: ['task_id' => (int) $taskId],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json(['ok' => true]);
    }

    // Tambah card baru
    public function store(Request $request, $columnId)
    {
        $request->validate(['title' => 'required|string']);

        $column = \App\Models\Column::findOrFail($columnId);
        $task = $column->tasks()->create([
            'title'    => $request->title,
            'priority' => $request->priority ?? 'medium',
            'position' => $column->tasks()->max('position') + 1,
        ]);

        broadcast(new BoardUpdated(
            boardId: $column->board_id,
            type: 'card_created',
            payload: ['task' => $task->load('assignee', 'comments')],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json($task, 201);
    }
}

// ─────────────────────────────────────────────────────────────
// CommentController — broadcast activity ke semua member
// ─────────────────────────────────────────────────────────────
class CommentController extends Controller
{
    public function store(Request $request, $taskId)
    {
        $request->validate(['body' => 'required|string']);

        $task    = \App\Models\Task::findOrFail($taskId);
        $comment = $task->comments()->create([
            'body'    => $request->body,
            'user_id' => auth()->id(),
        ]);

        $boardId = $task->column->board_id;

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'comment_added',
            payload: [
                'task_id' => (int) $taskId,
                'comment' => $comment->load('user'),
            ],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json($comment->load('user'), 201);
    }

    public function destroy($commentId)
    {
        $comment = \App\Models\Comment::findOrFail($commentId);
        $boardId = $comment->task->column->board_id;
        $comment->delete();

        broadcast(new BoardUpdated(
            boardId: $boardId,
            type: 'comment_deleted',
            payload: ['comment_id' => (int) $commentId, 'task_id' => $comment->task_id],
            actor: ['id' => auth()->id(), 'name' => auth()->user()->name],
        ));

        return response()->json(['ok' => true]);
    }
}