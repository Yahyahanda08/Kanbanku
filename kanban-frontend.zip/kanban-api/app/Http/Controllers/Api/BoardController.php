<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Board;
use App\Models\User;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;

class BoardController extends Controller
{
    use AuthorizesRequests;

    // ── GET /boards ───────────────────────────────────────────────────────────
    public function index(Request $request)
    {
        $boards = Board::where('owner_id', $request->user()->id)
            ->orWhereHas('members', fn($q) => $q->where('user_id', $request->user()->id))
            ->withCount('columns')
            ->latest()
            ->get();

        return response()->json($boards);
    }

    // ── POST /boards ──────────────────────────────────────────────────────────
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $board = Board::create([
            'name'        => $data['name'],
            'description' => $data['description'] ?? null,
            'owner_id'    => $request->user()->id,
        ]);

        // Owner otomatis jadi member dengan role 'owner'
        $board->members()->attach($request->user()->id, ['role' => 'owner']);

        // Buat 3 kolom default
        $board->columns()->createMany([
            ['name' => 'To Do',       'position' => 0],
            ['name' => 'In Progress', 'position' => 1],
            ['name' => 'Done',        'position' => 2],
        ]);

        return response()->json($board->load('columns'), 201);
    }

    // ── GET /boards/{board} ───────────────────────────────────────────────────
    public function show(Board $board)
    {
        $this->authorize('view', $board);

        return response()->json(
            $board->load(['columns.tasks.assignee', 'columns.tasks.comments.user', 'members'])
        );
    }

    // ── PUT /boards/{board} ───────────────────────────────────────────────────
    public function update(Request $request, Board $board)
    {
        $this->authorize('update', $board);

        $board->update($request->validate([
            'name'        => 'sometimes|string|max:255',
            'description' => 'nullable|string',
        ]));

        return response()->json($board);
    }

    // ── DELETE /boards/{board} ────────────────────────────────────────────────
    public function destroy(Board $board)
    {
        $this->authorize('delete', $board);
        $board->delete();
        return response()->json(null, 204);
    }

    // ── POST /boards/{board}/invite ───────────────────────────────────────────
    public function invite(Request $request, Board $board)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'role'  => 'in:member,viewer',
        ]);

        $user = User::where('email', $request->email)->firstOrFail();

        // Cek apakah sudah anggota
        if ($board->members()->where('user_id', $user->id)->exists()) {
            return response()->json([
                'message' => 'Pengguna sudah menjadi anggota board ini.'
            ], 422);
        }

        // Attach dengan role (default: member)
        $board->members()->attach($user->id, [
            'role' => $request->role ?? 'member',
        ]);

        return response()->json([
            'message' => 'Undangan berhasil dikirim.',
            'user'    => $user,
        ]);
    }

    // ── DELETE /boards/{board}/members/{user} ─────────────────────────────────
    public function removeMember(Board $board, User $user)
    {
        $this->authorize('update', $board);

        // Jangan hapus owner
        if ($board->owner_id === $user->id) {
            return response()->json(['message' => 'Tidak bisa menghapus owner board.'], 422);
        }

        $board->members()->detach($user->id);

        return response()->json(['message' => 'Anggota berhasil dihapus.']);
    }

    // ── PUT /boards/{board}/members/{user}/role ───────────────────────────────
    public function updateMemberRole(Request $request, Board $board, User $user)
    {
        $this->authorize('update', $board);

        $request->validate(['role' => 'required|in:member,viewer,admin']);

        $board->members()->updateExistingPivot($user->id, ['role' => $request->role]);

        return response()->json(['message' => 'Role berhasil diupdate.']);
    }

    // ── PUT /boards/{board}/columns/reorder ───────────────────────────────────
    public function reorderColumns(Request $request, Board $board)
    {
        $this->authorize('update', $board);

        $request->validate([
            'columns'   => 'required|array',
            'columns.*' => 'integer|exists:columns,id',
        ]);

        foreach ($request->columns as $position => $columnId) {
            $board->columns()
                  ->where('id', $columnId)
                  ->update(['position' => $position]);
        }

        return response()->json(['message' => 'Urutan kolom berhasil diupdate.']);
    }
}