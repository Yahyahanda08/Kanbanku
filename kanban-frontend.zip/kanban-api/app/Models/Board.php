<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Board extends Model
{
    use HasFactory;

    protected $fillable = [
    'name',
    'description',
    'owner_id',
    ];

    public function members()
{
    return $this->belongsToMany(User::class, 'board_user')
                ->withPivot('role')
                ->withTimestamps();
    }
    public function columns()
    {
    return $this->hasMany(Column::class);
    }
}
